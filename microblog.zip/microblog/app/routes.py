from flask import render_template, flash, redirect, url_for, request
from app import app, db
from app.forms import LoginForm, RegistrationForm, EditProfileForm, QuoteForm
import sqlalchemy as sa
from app.models import User, Quote
from urllib.parse import urlsplit
from flask_login import current_user, login_user, logout_user, login_required
from datetime import datetime
import random

@app.before_request
def before_request():
    if current_user.is_authenticated:
        current_user.last_seen = datetime.now()
        db.session.commit()

@app.route('/')
def index():
    quote = db.session.scalar(sa.select(Quote).order_by(sa.func.random()))
    
    if not quote:
        quotes_count = db.session.scalar(sa.select(sa.func.count(Quote.id)))
        if quotes_count > 0:
            random_offset = random.randint(0, quotes_count - 1)
            quote = db.session.scalar(sa.select(Quote).offset(random_offset).limit(1))
    
    return render_template('index.html', title='Главная - Случайная цитата', quote=quote)

@app.route('/register', methods=['GET','POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Поздравляем, вы успешно зарегистрированы!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Регистрация', form=form)

@app.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = db.session.scalar(
            sa.select(User).where(User.username == form.username.data)
        )
        if user is None or not user.check_password(form.password.data):
            flash("Неверный логин или пароль")
            return redirect(url_for('login'))
        login_user(user, remember=form.remember_me.data)
        next_page = request.args.get('next')
        if not next_page or urlsplit(next_page).netloc != '':
            next_page = url_for('index')
        return redirect(next_page)
        
    return render_template('login.html', title="Вход", form=form)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/user/<username>')
@login_required
def user(username):
    user = db.first_or_404(sa.select(User).where(User.username == username))
    
    # Получаем статистику пользователя
    user_quotes_count = db.session.scalar(
        sa.select(sa.func.count(Quote.id)).where(Quote.user_id == user.id)
    )
    
    return render_template('user.html', 
                         user=user, 
                         user_quotes_count=user_quotes_count,
                         user_join_date=user.last_seen)

@app.route("/edit_profile", methods=['GET','POST'])
@login_required
def edit_profile():
    form = EditProfileForm(current_user.username)
    if form.validate_on_submit():
        current_user.username = form.username.data
        current_user.about_me = form.about_me.data
        db.session.commit()
        flash("Ваши изменения сохранены!")
        return redirect(url_for('user', username=current_user.username))
    elif request.method == 'GET':
        form.username.data = current_user.username
        form.about_me.data = current_user.about_me
    return render_template('edit_profile.html', title="Редактирование профиля", form=form)

@app.route('/quotes')
def quotes():
    quote = db.session.scalar(sa.select(Quote).order_by(sa.func.random()))
    
    if not quote:
        quotes_count = db.session.scalar(sa.select(sa.func.count(Quote.id)))
        if quotes_count > 0:
            random_offset = random.randint(0, quotes_count - 1)
            quote = db.session.scalar(sa.select(Quote).offset(random_offset).limit(1))
    
    return render_template('quotes.html', title='Случайная цитата', quote=quote)

@app.route('/add_quote', methods=['GET', 'POST'])
@login_required
def add_quote():
    form = QuoteForm()
    if form.validate_on_submit():
        quote = Quote(
            text=form.text.data,
            author=form.author.data,
            user_id=current_user.id
        )
        db.session.add(quote)
        db.session.commit()
        flash('Цитата успешно добавлена!')
        return redirect(url_for('quotes'))
    return render_template('add_quote.html', title='Добавить цитату', form=form)

@app.route('/quote/<int:quote_id>/share')
def share_quote(quote_id):
    quote = db.session.get(Quote, quote_id)
    if not quote:
        flash('Цитата не найдена')
        return redirect(url_for('quotes'))
    
    share_text = f'"{quote.text}" - {quote.author}'
    return render_template('share_quote.html', title='Поделиться цитатой', 
                         quote=quote, share_text=share_text)

@app.route('/all_quotes')
@login_required
def all_quotes():
    quotes = db.session.scalars(
        sa.select(Quote).order_by(Quote.created_at.desc())
    ).all()
    return render_template('all_quotes.html', title='Все цитаты', quotes=quotes)

@app.route('/quote/<int:quote_id>/delete', methods=['POST'])
@login_required
def delete_quote(quote_id):
    quote = db.session.get(Quote, quote_id)
    if not quote:
        flash('Цитата не найдена')
        return redirect(url_for('all_quotes'))
    
    if quote.user_id != current_user.id:
        flash('Вы можете удалять только свои цитаты')
        return redirect(url_for('all_quotes'))
    
    db.session.delete(quote)
    db.session.commit()
    flash('Цитата успешно удалена')
    return redirect(url_for('all_quotes'))

@app.route('/search_quotes')
def search_quotes():
    query = request.args.get('q', '')
    quotes = []
    if query:
        quotes = db.session.scalars(
            sa.select(Quote)
            .where(
                sa.or_(
                    Quote.text.ilike(f'%{query}%'),
                    Quote.author.ilike(f'%{query}%')
                )
            )
            .order_by(Quote.created_at.desc())
        ).all()
    return render_template('search_quotes.html', title='Поиск цитат', quotes=quotes, query=query)