from flask_wtf import FlaskForm
from flask_wtf.form import _Auto
from wtforms import TextAreaField,StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import Length, ValidationError, DataRequired, Email, EqualTo
import sqlalchemy as sa
from app import db
from app.models import User

class EditProfileForm(FlaskForm):
    username=StringField("Имя пользователя",validators=[DataRequired()])
    about_me=TextAreaField("Обо мне", validators=[Length(min=0,max=140)])
    submit=SubmitField('Подтвердить')
    def __init__(self, original_username, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.original_username=original_username
        
    def validate_username(self,username):
        if username.data!=self.original_username:
            user=db.session.scalar(sa.select(User).where(
                User.username==self.username.data))
            if user is not None:
                raise ValidationError("Такой логин уже существует")
class LoginForm(FlaskForm):
    username=StringField("Username",validators=[DataRequired()])
    password=PasswordField("Password",validators=[DataRequired()])
    remember_me=BooleanField('Remember Me')
    submit=SubmitField('Sign In')
class RegistrationForm(FlaskForm):
    username=StringField("Username",validators=[DataRequired()])
    email=StringField("Email",validators=[DataRequired(),Email()])
    password=PasswordField('Password',validators=[DataRequired()])
    password2=PasswordField('Repeat Password',validators=[DataRequired(),
                                                          EqualTo('password')])
    submit=SubmitField('Register')
    def validate_username(self,username):
        user=db.session.scalar(sa.select(User).where(
            User.username==username.data))
        if user is not None:
            raise ValidationError("Такой логин уже существует")
    def validate_email(self,email):
        user = db.session.scalar(sa.select(User).where(
            User.email == email.data))
        if user is not None:
            raise ValidationError('Такая почта уже зарегистрирована')

class QuoteForm(FlaskForm):
    text = TextAreaField("Текст цитаты", validators=[DataRequired(), Length(min=10, max=500)])
    author = StringField("Автор", validators=[DataRequired(), Length(min=1, max=100)])
    submit = SubmitField('Добавить цитату')